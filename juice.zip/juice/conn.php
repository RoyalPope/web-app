<?php
$xonn = mysqli_connect('localhost','Pope','earth3','juice_depot');
?>