<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="stylee.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="nav">
    <div>
        <h1>Juice Depot</h1>
    </div>
    <div class="links">
        <a href="product.php">Products</a>
        <a href="stock.php">Stock In</a>
        <a href="customer.php">customer</a>
        <a href="payments.php">Pays</a>
        <a href="dsales.php">sales</a>
        <a href="zend.php">Log Out</a>
    </div>
    </div>
</body>
</html>