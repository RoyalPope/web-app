<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylee.css">
    <title>Document</title>
</head>
<body>
    <form action="log.php" method="post">
        <h1>LOG IN</h1>
        <div class="inputs">
        Username: <input type="text" name="uname">
        </div>
        <div class="inputs">
            Password: <input type="password" name="pass">
        </div>
        <input type="submit" value="submit">
    </form>
</body>
</html>